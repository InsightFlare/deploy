import * as React from "react";
import type { RemixiconComponentType } from "@remixicon/react";
import { RiInformationLine } from "@remixicon/react";
import { AlertDialog as AlertDialogPrimitive } from "radix-ui";

import { cn } from "../../lib/utils";
import { OverlayFrame } from "./layer/layer-manager";
import { LayerPortal } from "./layer/layer-portal";
import { AppOverlay } from "./app-overlay";
import { Button } from "./button";

const AlertDialogOpenContext = React.createContext(false);

function AlertDialog({
  defaultOpen = false,
  open,
  onOpenChange,
  ...rootProps
}: React.ComponentProps<typeof AlertDialogPrimitive.Root>) {
  const [uncontrolledOpen, setUncontrolledOpen] = React.useState(defaultOpen);
  const isControlled = open !== undefined;
  const currentOpen = isControlled ? open : uncontrolledOpen;
  const handleOpenChange = React.useCallback(
    (nextOpen: boolean) => {
      if (!isControlled) setUncontrolledOpen(nextOpen);
      onOpenChange?.(nextOpen);
    },
    [isControlled, onOpenChange],
  );

  return (
    <AlertDialogOpenContext.Provider value={currentOpen}>
      <AlertDialogPrimitive.Root
        data-slot="alert-dialog"
        {...rootProps}
        open={currentOpen}
        onOpenChange={handleOpenChange}
      />
    </AlertDialogOpenContext.Provider>
  );
}

function AlertDialogTrigger({
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Trigger>) {
  return (
    <AlertDialogPrimitive.Trigger data-slot="alert-dialog-trigger" {...props} />
  );
}

function AlertDialogPortal({ children }: { children: React.ReactNode }) {
  const open = React.useContext(AlertDialogOpenContext);
  return (
    <OverlayFrame kind="alert-dialog" open={open}>
      {children}
    </OverlayFrame>
  );
}

function AlertDialogOverlay({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"div">) {
  const open = React.useContext(AlertDialogOpenContext);

  return (
    <AppOverlay
      className={cn(className)}
      data-slot="alert-dialog-overlay"
      layerId="alert-dialog-overlay"
      open={open}
      {...props}
    />
  );
}

function AlertDialogContent({
  className,
  size = "default",
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Content> & {
  size?: "default" | "sm";
}) {
  return (
    <AlertDialogPortal>
      <LayerPortal slot="backdrop">
        <AlertDialogOverlay />
      </LayerPortal>
      <LayerPortal slot="surface">
        <AlertDialogPrimitive.Content
          data-slot="alert-dialog-content"
          data-size={size}
          className={cn(
            "pointer-events-auto group/alert-dialog-content fixed top-1/2 left-1/2 grid w-full -translate-x-1/2 -translate-y-1/2 gap-4 rounded-none bg-background p-4 ring-1 ring-foreground/10 duration-100 outline-none data-[size=default]:max-w-xs data-[size=sm]:max-w-xs data-[size=default]:sm:max-w-sm data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95",
            className,
          )}
          {...props}
        />
      </LayerPortal>
    </AlertDialogPortal>
  );
}

function AlertDialogHeader({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="alert-dialog-header"
      className={cn(
        "grid grid-rows-[auto_1fr] place-items-center gap-1.5 text-center has-data-[slot=alert-dialog-media]:grid-rows-[auto_auto_1fr] has-data-[slot=alert-dialog-media]:gap-x-4 sm:group-data-[size=default]/alert-dialog-content:place-items-start sm:group-data-[size=default]/alert-dialog-content:text-left sm:group-data-[size=default]/alert-dialog-content:has-data-[slot=alert-dialog-media]:grid-rows-[auto_1fr]",
        className,
      )}
      {...props}
    />
  );
}

function AlertDialogFooter({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="alert-dialog-footer"
      className={cn(
        "flex flex-col-reverse gap-2 group-data-[size=sm]/alert-dialog-content:grid group-data-[size=sm]/alert-dialog-content:grid-cols-2 sm:flex-row sm:justify-end",
        className,
      )}
      {...props}
    />
  );
}

function AlertDialogMedia({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="alert-dialog-media"
      className={cn(
        "mb-2 inline-flex size-10 items-center justify-center rounded-none bg-muted sm:group-data-[size=default]/alert-dialog-content:row-span-2 *:[svg:not([class*='size-'])]:size-6",
        className,
      )}
      {...props}
    />
  );
}

function AlertDialogTitle({
  className,
  children,
  icon: Icon = RiInformationLine,
  iconClassName,
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Title> & {
  icon?: RemixiconComponentType | null;
  iconClassName?: string;
}) {
  return (
    <AlertDialogPrimitive.Title
      data-slot="alert-dialog-title"
      className={cn(
        "inline-flex items-center gap-2 text-sm font-medium sm:group-data-[size=default]/alert-dialog-content:group-has-data-[slot=alert-dialog-media]/alert-dialog-content:col-start-2",
        className,
      )}
      {...props}
    >
      {Icon ? <Icon className={cn("size-4 shrink-0", iconClassName)} /> : null}
      <span className="min-w-0">{children}</span>
    </AlertDialogPrimitive.Title>
  );
}

function AlertDialogDescription({
  className,
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Description>) {
  return (
    <AlertDialogPrimitive.Description
      data-slot="alert-dialog-description"
      className={cn(
        "text-xs/relaxed text-balance text-muted-foreground md:text-pretty *:[a]:underline *:[a]:underline-offset-3 *:[a]:hover:text-foreground",
        className,
      )}
      {...props}
    />
  );
}

function AlertDialogAction({
  className,
  variant = "default",
  size = "default",
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Action> &
  Pick<React.ComponentProps<typeof Button>, "variant" | "size">) {
  return (
    <Button variant={variant} size={size} asChild>
      <AlertDialogPrimitive.Action
        data-slot="alert-dialog-action"
        className={cn(className)}
        {...props}
      />
    </Button>
  );
}

function AlertDialogCancel({
  className,
  variant = "outline",
  size = "default",
  ...props
}: React.ComponentProps<typeof AlertDialogPrimitive.Cancel> &
  Pick<React.ComponentProps<typeof Button>, "variant" | "size">) {
  return (
    <Button variant={variant} size={size} asChild>
      <AlertDialogPrimitive.Cancel
        data-slot="alert-dialog-cancel"
        className={cn(className)}
        {...props}
      />
    </Button>
  );
}

export {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogMedia,
  AlertDialogOverlay,
  AlertDialogPortal,
  AlertDialogTitle,
  AlertDialogTrigger,
};

export type AlertDialogProps = React.ComponentPropsWithRef<typeof AlertDialog>;
export type AlertDialogActionProps = React.ComponentPropsWithRef<
  typeof AlertDialogAction
>;
export type AlertDialogCancelProps = React.ComponentPropsWithRef<
  typeof AlertDialogCancel
>;
export type AlertDialogContentProps = React.ComponentPropsWithRef<
  typeof AlertDialogContent
>;
export type AlertDialogDescriptionProps = React.ComponentPropsWithRef<
  typeof AlertDialogDescription
>;
export type AlertDialogFooterProps = React.ComponentPropsWithRef<
  typeof AlertDialogFooter
>;
export type AlertDialogHeaderProps = React.ComponentPropsWithRef<
  typeof AlertDialogHeader
>;
export type AlertDialogMediaProps = React.ComponentPropsWithRef<
  typeof AlertDialogMedia
>;
export type AlertDialogOverlayProps = React.ComponentPropsWithRef<
  typeof AlertDialogOverlay
>;
export type AlertDialogPortalProps = React.ComponentPropsWithRef<
  typeof AlertDialogPortal
>;
export type AlertDialogTitleProps = React.ComponentPropsWithRef<
  typeof AlertDialogTitle
>;
export type AlertDialogTriggerProps = React.ComponentPropsWithRef<
  typeof AlertDialogTrigger
>;
