import * as React from "react";
import { useEffect, useMemo, useState } from "react";
import {
  AnimatePresence,
  motion,
  type TargetAndTransition,
} from "motion/react";

export type TransitionType =
  "fade" | "slide" | "scale" | "slideUp" | "slideDown" | "crossFade";

export interface AutoTransitionProps extends Omit<
  React.HTMLAttributes<HTMLElement>,
  "children" | "className"
> {
  children: React.ReactNode;
  as?: "div" | "span" | "g" | "tbody" | "tr" | "li";
  className?: string;
  duration?: number;
  type?: TransitionType;
  initial?: boolean;
  custom?: unknown;
  transitionKey?: string | number;
  presenceMode?: "sync" | "wait" | "popLayout";
  customVariants?: {
    initial?: TargetAndTransition | ((custom: unknown) => TargetAndTransition);
    animate?: TargetAndTransition | ((custom: unknown) => TargetAndTransition);
    exit?: TargetAndTransition | ((custom: unknown) => TargetAndTransition);
  };
}

const transitionVariants: Record<
  TransitionType,
  {
    initial: TargetAndTransition;
    animate: TargetAndTransition;
    exit: TargetAndTransition;
  }
> = {
  fade: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 },
  },
  slide: {
    initial: { opacity: 0, x: -20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: 20 },
  },
  slideUp: {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 },
  },
  slideDown: {
    initial: { opacity: 0, y: -20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: 20 },
  },
  scale: {
    initial: { opacity: 0, scale: 0.95 },
    animate: { opacity: 1, scale: 1 },
    exit: { opacity: 0, scale: 0.95 },
  },
  crossFade: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 },
  },
};

export const AutoTransition = React.forwardRef<
  HTMLElement,
  AutoTransitionProps
>(function AutoTransition(
  {
    children,
    as = "div",
    className = "",
    duration = 0.3,
    type = "fade",
    initial = true,
    custom,
    transitionKey,
    presenceMode = "wait",
    customVariants,
    ...motionProps
  },
  ref,
) {
  const [hasRendered, setHasRendered] = useState(initial);

  useEffect(() => {
    if (!hasRendered) setHasRendered(true);
  }, [hasRendered]);

  const resolvedPresenceMode =
    type === "crossFade" ? "popLayout" : presenceMode;

  const key = useMemo(() => {
    if (transitionKey !== undefined) return String(transitionKey);
    if (!children) return "empty";

    const childArray = React.Children.toArray(children);
    const firstChild = childArray[0];

    if (React.isValidElement(firstChild) && firstChild.key) {
      return String(firstChild.key);
    }

    if (React.isValidElement(firstChild)) {
      const childType = firstChild.type;
      if (typeof childType === "string") return childType;
      if (typeof childType === "function") {
        return (
          (childType as { displayName?: string; name?: string }).displayName ||
          childType.name ||
          "component"
        );
      }
    }

    return typeof firstChild === "string" || typeof firstChild === "number"
      ? String(firstChild)
      : "node";
  }, [children, transitionKey]);

  const selectedVariants = customVariants || transitionVariants[type];
  const shouldAnimate = initial || hasRendered;
  const MotionComponent = (
    as === "g"
      ? motion.g
      : as === "tbody"
        ? motion.tbody
        : as === "tr"
          ? motion.tr
          : as === "li"
            ? motion.li
            : as === "span"
              ? motion.span
              : motion.div
  ) as React.ElementType;

  return (
    <AnimatePresence mode={resolvedPresenceMode} custom={custom}>
      <MotionComponent
        {...motionProps}
        ref={ref}
        key={key}
        className={className}
        custom={custom}
        variants={selectedVariants}
        initial={shouldAnimate ? "initial" : false}
        animate="animate"
        exit="exit"
        transition={{ duration }}
      >
        {children}
      </MotionComponent>
    </AnimatePresence>
  );
});

AutoTransition.displayName = "AutoTransition";
